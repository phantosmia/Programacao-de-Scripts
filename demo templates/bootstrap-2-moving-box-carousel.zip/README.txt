A Pen created at CodePen.io. You can find this one at http://codepen.io/redfrost/pen/mzHjb.

 RESPONSIVE MOVING BOX CAROUSEL DEMO
